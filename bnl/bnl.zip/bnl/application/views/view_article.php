<script type="text/javascript">
	function load_jquery(){
		$('#slider_article').orbit({
			bullets: true,	
		});
		$("#tab_review").tabify();
		$("#tab_today_in_history").tabify();
		$("#tab_fun_fact").tabify();
		$('#back_to_top').backToTop();
	}
</script>
<!-- banner -->
<div id="top_breadcrumb">
	<span class="title title_style">article</span>
	<div class="bc_right">
		<img src="<?php echo base_url(); ?>assets/images/bnl_icon.png" /> > Article
	</div>
</div>
<div class="clear"></div>
<div id="container" class="bg_white">
	<div class="main_content bg_white">
		<div class="title_style">hot news</div>
		<div id="slider_article"> 
			<img src="<?php echo base_url(); ?>dummy_img/creed.jpg" data-caption="#caption1" />
			<img src="<?php echo base_url(); ?>dummy_img/1.jpg" data-caption="#caption2"  />
			<img src="<?php echo base_url(); ?>dummy_img/2.jpg" data-caption="#caption3"  />
		</div>
		<!-- Captions for Orbit -->
		<span class="orbit-caption" id="caption1">
			Today | <span class="subtitle">Editor Pick</span></br>
			<a href="">Creed TO STAGE Concerts In Four Cities In Indonesia</a>
		</span>
		<span class="orbit-caption" id="caption2">
			Today | <span class="subtitle">Editor Pick</span></br>
			<a href="">Risus ut turpis, placerat placerat proin ut nec nisi et dis et! Aliquam nascetur</a>
		</span>
		<span class="orbit-caption" id="caption3">
			Today | <span class="subtitle">Editor Pick</span></br>
			<a href="">Ultrices aliquam? Integer tortor, dapibus, odio lectus platea, tincidunt velit nascetur, elementum lectus.</a>
		</span>
		<br class="clear">
		<div id='img_section'>
			<span class="title_style">INTERVIEWS</span><a href=""><span class="see_more">More Interviews</span></a>
			<img src="<?php echo base_url(); ?>dummy_img/1.jpg" />
			<span class="caption">
				<a href="">Interview With Lifehouse at RADIO Jakarta</a>
			</span>
		</div>						
		<div id='img_section' style="margin-left:50px;">
			<span class="title_style">EVENT REPORTS</span><a href=""><span class="see_more">More Event Reports</span></a>
			<img src="<?php echo base_url(); ?>dummy_img/2.jpg" />
			<span class="caption">
				<a href="">The SCRipt Life In Guinness Arthur Day At JAKARTA</a>
			</span>
		</div>
		<br class="clear" />
		<div id='dothemath'>
			<span class="title_style">Do The Math</span><a href=""><span class="see_more">More Do The Math</span></a>
			<hr class="line_style" />
			<img src="<?php echo base_url(); ?>assets/images/dothemath.jpg" />
			<span class="caption">
				Bintang Lima - Dewa
			</span>
		</div>
		<br class="clear" />
		<br class="clear" />
	</div>
	<div class="sidebar">
		<div id="most_popular_news">
			<div class="title_style title">most popular news</div>
			<ul>
				<?php for ($i=1; $i < 5; $i++) { ?>
					<li>
						<div class="desc">
							<span>Yesterday</span><br />
							<a href="">Title Goes Here Lorem ipsum sir Amet Sirtum</a>
						</div>
						<img src="<?php echo base_url('playlist/'.$i.'.jpg'); ?>" />
						<div class="clear"></div>
					</li>
				<?php }?>
			</ul>
		</div>

		<div id="tab_sidebar" class="reviews">
			<div class="title title_style">reviews</div>
			<ul id="tab_review" class="paging">
				<li class="active"><a href="#review1" class="link"></a></li>
				<li><a href="#review2" class="link"></a></li>
				<li><a href="#review3" class="link"></a></li>
			</ul>
			<hr class="line_style" />
				<?php for ($i=1; $i < 4; $i++) { ?>
					<div id="review<?php echo $i; ?>">
						<img src="<?php echo base_url('playlist/'.$i.'.jpg'); ?>" />
						<div class="desc">
							<span class="info">New Album</span>
							<h4>Muse - 'The 2nd Law'</h4>
							<p>New experience sound and more to rock gravida nibh vel velit auctor aliquet.</p>
						</div>
					</div>
				<?php }?>
			<div class="clear"></div>
		</div>
		
		<div id="tab_sidebar" class="today_in_history">
			<div class="title title_style">today in history</div>
			<ul id="tab_today_in_history" class="paging">
				<li class="active"><a href="#today_in_history1" class="link"></a></li>
				<li><a href="#today_in_history2" class="link"></a></li>
				<li><a href="#today_in_history3" class="link"></a></li>
			</ul>
			<hr class="line_style" />
				<?php for ($i=1; $i < 4; $i++) { ?>
					<div id="today_in_history<?php echo $i; ?>">
						<img src="<?php echo base_url('playlist/'.$i.'.jpg'); ?>" />
						<div class="desc">
							<span class="date">Feb 9, 1985</span>
							<h4>American composer Phillip Glass is Born</h4>
						</div>
					</div>
				<?php }?>
			<div class="clear"></div>
		</div>		
		<div id="tab_sidebar" class="fun_fact">
			<div class="title title_style">today in history</div>
			<ul id="tab_fun_fact" class="paging">
				<li class="active"><a href="#fun_fact1" class="link"></a></li>
				<li><a href="#fun_fact2" class="link"></a></li>
				<li><a href="#fun_fact3" class="link"></a></li>
			</ul>
			<hr class="line_style" />
				<?php for ($i=1; $i < 4; $i++) { ?>
					<div id="fun_fact<?php echo $i; ?>">
						<img src="<?php echo base_url('playlist/'.$i.'.jpg'); ?>" />
						<div class="desc">
							<p>
								<img src="<?php echo base_url('assets/images/quote1.png'); ?>" class="quote1" /><h4>madonna</h4>
								When Madonna was 15 years old, she got grounded for the whole summer, for sneaking out to see David Bowie in concert.
							</p>
							<img src="<?php echo base_url('assets/images/quote2.png'); ?>" class="quote2" />
						</div>
					</div>
				<?php }?>
			<div class="clear"></div>
		</div>
	</div>
	<br class="clear" />
</div>

<div class="clear"></div>