				</div>
			</div>
			<!-- end of right side -->
			<!-- end of content -->			
			<!-- footer -->
			<div id="footer">
				<a href="">About Us</a>
				<a href="">Contact Us</a>
				<a href="">RSS</a>
				<a href="">Internship</a>
				<a href="">Career</a>
				<a href="">Advertise</a>
				<a href="#" id="back_to_top" style="position: absolute; right: 36px;bottom: 40px;">Back To Top <img src="<?php echo base_url();?>assets/images/to_top.png"></a>
				<div class="copyright">© 2013 Bold n Loud. All rights reserved</div>
			</div>
			<!-- end of footer -->
		</div>
	</body>
</html>