<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Bold n Loud</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/reset-min.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/style.css" media="screen" />
	<link href="<?php echo base_url(); ?>assets/css/jquery.fancybox.css" type="text/css" rel="stylesheet" />
	<link href="<?php echo base_url(); ?>assets/css/slider.css" type="text/css" rel="stylesheet" />
	<link href="<?php echo base_url(); ?>assets/css/coverflow.css" type="text/css" rel="stylesheet" />
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/orbit-1.2.3.css">
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'> 
	<!-- <link href="<?php echo base_url(); ?>assets/css/elastislide.css" type="text/css" rel="stylesheet" /> -->
	<link href="<?php echo base_url(); ?>assets/css/jquery.jcarousel.css" type="text/css" rel="stylesheet" />
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.fancybox.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.jcarousel.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.tabify.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-ui.min.js" ></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/slides.min.jquery.js" ></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.backtotop.min.js" ></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.orbit-1.2.3.js"></script>	
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/script.js"></script>	
	</head>

	<body>
		<div id="wrapper">
			<!-- header -->
			<div id="header">
				<div class="notif">10</div>
				<a href="<?php echo site_url('home'); ?>" id="home" onclick="load_content('#home');return false;"><img src="<?php echo base_url(); ?>assets/images/logo.png" class="logo" /></a>
				<div id="main_menu" class="main_menu">
					<a href="<?php echo site_url(); ?>">PLAYLIST</a><span class="dots">&bull;</span>
					<a href="<?php echo site_url(); ?>">TIMELINE</a><span class="dots">&bull;</span>
					<a href="<?php echo site_url('article'); ?>" <?php  echo ($menu == 'article') ? 'class="selected"' : '' ; ?> >ARTICLES</a><span class="dots">&bull;</span>
					<a href="<?php echo site_url(); ?>">GALLERY</a><span class="dots">&bull;</span>
					<a href="<?php echo site_url(); ?>">SCHEDULES</a>
				</div>
				<div class="login">
					<a href="index.html"><img src="<?php echo base_url(); ?>assets/images/search_icon.png" class="search" /></a>
					<a href="index.html"><img src="<?php echo base_url(); ?>assets/images/login_btn.png"/></a>
				</div>
			</div>
			<div id="top_player">

			</div>
			<!-- end of header -->
			<!-- content -->
			<div id="body_wrap">
				<div id="content">