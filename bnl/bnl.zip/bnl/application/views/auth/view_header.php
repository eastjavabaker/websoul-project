<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="pt-br">
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>tikkutikku.com</title>
	
	<link rel="shortcut icon" href="images/favicon.ico">
	<!--<link href="assets/css/styles.css" type="text/css" media="all" rel="stylesheet" />-->
	<link href="<?php echo base_url();?>assets/css/admin.css" type="text/css" media="all" rel="stylesheet" />
</head>
	<body>