		</div>

	</div>


	<div id="footer" class="content">

		<div class="container">

		
			<p class="copyright">Powered by &copy;TIKKUTIKKU 2012. All rights reserved. Terms and conditions</p>


		</div>

	</div>

</div>
	
</body>
</html>