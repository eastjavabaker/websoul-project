<h1 class="headingleft">Control Panel</h1>
<div id="clear"></div>
<hr>
<div class="module">
			
				<h2><strong>Manage Pre-Employee Screening</strong></h2>
			
				<p>You can update a Pre-Employee Screening.</p>
			
				<p><a href="<?php echo site_url('admin/pre_employee');?>" class="button">Manage Pre-Employee Screening</a></p>
				
</div>
<div class="module">
			
				<h2><strong>Manage Your About Us Page</strong></h2>
			
				<p>You can update a About Us Page Content.</p>
			
				<p><a href="<?php echo site_url('admin/about');?>" class="button">Manage About Us Page</a></p>
				
</div>
<div class="module">
			
				<h2><strong>Manage Your Vendor Screening</strong></h2>
			
				<p>You can update a Vendor Screening Content.</p>
			
				<p><a href="<?php echo site_url('admin/vendor');?>" class="button">Manage Vendor Screening</a></p>
				
</div>
<div class="module">
			
				<h2><strong>Manage Your Know Your Customer</strong></h2>
			
				<p>You can update a Know Your Customer Content.</p>
			
				<p><a href="<?php echo site_url('admin/know_customer');?>" class="button">Manage Know Your Customer</a></p>
				
</div>
<div class="module">
			
				<h2><strong>Manage Your Background Checks</strong></h2>
			
				<p>You can update a Background Checks Content.</p>
			
				<p><a href="<?php echo site_url('admin/background_check');?>" class="button">Manage Background Checks</a></p>
				
</div>

<div class="module">
			
				<h2><strong>Manage Your FCPA</strong></h2>
			
				<p>You can update a FCPA Content.</p>
			
				<p><a href="<?php echo site_url('admin/fcpa');?>" class="button">Manage FCPA</a></p>
				
</div>
