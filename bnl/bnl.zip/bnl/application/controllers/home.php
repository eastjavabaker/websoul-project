<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

	function __construct()
	{
		parent::__construct();
	}

	public function index($loader = '')
	{	
		if($loader == 'ajaxload'){

			$this->load->view('view_home');

		}else{

			$this->load->view('view_header', array('menu'=>'home'));
			$this->load->view('view_home');
			$this->load->view('view_footer');
			
		}
		
	}

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */