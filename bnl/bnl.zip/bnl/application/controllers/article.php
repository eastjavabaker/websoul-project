<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Article extends CI_Controller {

	function __construct()
	{
		parent::__construct();
	}

	public function index($loader = '')
	{	
		if($loader == 'ajaxload'){

			$this->load->view('view_article');

		}else{

			$this->load->view('view_header', array('menu'=>'article'));
			$this->load->view('view_article');
			$this->load->view('view_footer');
			
		}
		
	}

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */