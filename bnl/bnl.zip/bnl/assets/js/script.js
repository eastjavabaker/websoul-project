var pages = {
  'home' : {id: '#home'},
  'news' : {id: '#news'},
};

function getContent(url){
  $('#content').fadeOut('slow', function(){
    $('<div id="loadingContent"></div>').insertBefore('#footer');
    $('#content').load(url+'/ajaxload', function(response, status, xhr){
      $('#loadingContent').remove();
      $('#content').fadeIn('slow');
      load_jquery();
    });
  });
}

function load_content(id_link){
    var link = $(id_link).attr('href');
    jQuery('.selected', $('#main_menu')).attr('class', '');
    history.pushState('', '', link);
    if(id_link == '#home'){
      getContent(link+'/index');
    }else{
      getContent(link);
    }
    return false;
  }

$(document).ready(function(){
  // var initpopstate = false;
  // window.addEventListener('popstate', function (e){
  //   if(!('state' in window.history) && !initpopstate){
  //     initpopstate = true; 
  //     return;
  //   }
    
  //   var page = window.location.pathname.substring(16);
  //   if(page == '') page = 'welcome';
  //   if(pages[page] != undefined){
  //     var A = $(pages[page].id);
  //     jQuery('.selected', A.parents('#mainMenu')).attr('class', '');
  //     A.attr('class', 'selected');
  //   }
  //   getContent(document.URL);
  // });
  load_jquery();
  $('#main_menu a').click(function(){
    var A = $(this);
    jQuery('.selected', A.parents('#main_menu')).attr('class', '');
    A.attr('class', 'selected');
    history.pushState('', '', A.attr('href'));
    getContent(A.attr('href')+'/index');
    return false;
  });

});